---
permalink: /
title: "About"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

I am a first-year (upcoming second-year) Ph.D. candidate in [Institute for Computational and Mathematical Engineering](https://icme.stanford.edu) (ICME) at [Stanford University](https://stanford.edu).

Before coming to Stanford, I graduated from [Peking University](http://english.pku.edu.cn) with B.S. degrees in Computational Mathematics and Computer Science. I did my senior thesis on *Global Optimization with Orthogonality Constraints via Stochastic Diffusions on Stiefel Manifold*, under the supervision of Dr. [Zaiwen Wen](http://bicmr.pku.edu.cn/~wenzw/index.html ) and Dr. [Rongjie Lai](http://homepages.rpi.edu/~lair/).

My current research interests lie broadly in optimization, stochastic methods and theoretical computer science. I am passionate about research unifying theoretical superiority and practical efficiency of numerical algorithms. I am fortunate to be able to work with Dr. [Yinyu Ye](https://web.stanford.edu/~yyye/) and Dr. [Aaron Sidford](http://www.aaronsidford.com) on these topics currently.

You can find more information in my [CV](https://cap.stanford.edu/profiles/viewCV?facultyId=180825&name=Honglin_Yuan) and my [Stanford profile](https://profiles.stanford.edu/honglin-yuan).

<!--For more info-->
------
<!--More info about configuring academicpages can be found in [the guide](https://academicpages.github.io/markdown/). The [guides for the Minimal Mistakes theme](https://mmistakes.github.io/minimal-mistakes/docs/configuration/) (which this theme was forked from) might also be helpful.-->
